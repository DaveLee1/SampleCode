export interface Products{
    id: number;
    prodName: string;
    price: number;
    description: string;
}

