export interface LoginUser {
    Email: string;
    Password: string;
}

